#include<stdio.h>
#include<conio.h>
void main()
{
 int i=1,n;
 printf("Enter the value of n");
 clrscr();
 scanf("%c",&n);
 while(i<=10)
   {
     printf("Hello Rajnish\n");
     i++;
     getch();
     }
 }
