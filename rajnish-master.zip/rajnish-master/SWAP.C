#include<stdio.h>

int main()
{
 int a=5, b=2;
 a=a+b;
 b=a-b;
 a=a-b;
printf("Value After Swap:\n");
 printf("Value of a=%d\n",a);
 printf("Value of b=%d\n",b);
 return 0;
 }

