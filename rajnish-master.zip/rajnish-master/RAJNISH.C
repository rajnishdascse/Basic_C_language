#include<stdio.h>
#include<conio.h>
 main()
{
 int a=5,b=4,c;
 clrscr();
 c=a;

 a=b;

 b=c;
 printf("a= %d",a);
 printf("b= %d",b);
 getch();
 }
