#include<stdio.h>
#include<conio.h>
void main()
{
 int a,days,months;
 clrscr();
 printf("Enter days");
 scanf("%d",&a);
 months=a/30;
 days=a%30;

 printf("%d months %d days",months,days);
 getch();

 }

 
 //This is only for testing github functiaonlaity (Push Working).